import React from "react";
import { ZegoCloudUserList } from "../../../../modules/tools/UserListManager";
export declare class OthersVideo extends React.PureComponent<{
    users: ZegoCloudUserList;
    others: number;
}> {
    render(): React.ReactNode;
}
