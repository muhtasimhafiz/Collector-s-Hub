import React from "react";
export declare class ZegoReconnect extends React.PureComponent<{
    content: string;
}> {
    render(): React.ReactNode;
}
