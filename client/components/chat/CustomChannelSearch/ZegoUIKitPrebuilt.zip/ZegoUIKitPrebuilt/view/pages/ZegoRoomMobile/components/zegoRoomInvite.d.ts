import React from "react";
import { ZegoCloudRTCCore } from "../../../../modules";
export declare class ZegoRoomInvite extends React.PureComponent<{
    core: ZegoCloudRTCCore;
    closeCallBack: () => void;
}> {
    render(): React.ReactNode;
}
